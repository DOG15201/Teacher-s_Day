#include <stdio.h>
#include <time.h>
#include <stdlib.h>

int main(void)
{
	char arr[1111] = { 0, };
	unsigned int x;
	int y, z, i;
	printf("�ο��� �Է����ּ���:");
	scanf_s("%d", &x);
	srand(time(NULL));

	for (i = 0; ; )
	{
		printf("����� -1, �̱�� 0:");
		scanf_s("%d", &y);
		if (y == -1)
		{
			return 0;
		}
		else if (y == 0)
		{
			z = rand(1) % x + 1;
			if (arr[z] == 0)
			{
				printf("%d\n", z);
				arr[z] = 1;
			}

			else if (arr[z] == 1)
			{
				printf("%d(�ߺ�)\n", z);
			}
		}

	}
}